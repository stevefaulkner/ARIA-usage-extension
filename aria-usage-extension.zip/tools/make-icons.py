#!/usr/bin/env python3
"""Rebuild the toolbar icons from the campervan artwork.

    python3 tools/make-icons.py path/to/artwork.png

Two compositions, chosen by size. The large icons carry the whole van so the
logo and strapline stay intact; the small ones crop to the front two thirds,
because at 16px the full van shrinks to a smear while the nose, windscreen and
front wheel still read as a vehicle.

Needs Pillow: pip install Pillow
"""

import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageEnhance

OUT_DIR = Path(__file__).resolve().parent.parent / "icons"

# Sampled from the artwork's own background, so the letterbox bars match.
BG = (73, 10, 34)

# The van without its roof antenna, which disappears at every icon size.
VAN_TOP, VAN_BOTTOM = 92, 300
VAN_LEFT, VAN_RIGHT = 12, 474

# Where the front crop stops: past the sliding door, before the strapline.
FRONT_WIDTH = 290

SS = 8  # supersample factor for the corner mask
CORNER = 0.18  # corner radius as a fraction of the icon


def compose(source, box, contrast=1.0):
    """Centre a crop on a square canvas of the artwork's background colour."""
    crop = source.crop(box)
    side = crop.width
    canvas = Image.new("RGB", (side, side), BG)
    canvas.paste(crop, (0, (side - crop.height) // 2))
    if contrast != 1.0:
        canvas = ImageEnhance.Contrast(canvas).enhance(contrast)
    return canvas


def rounded(canvas, size):
    """Downsample to `size` and knock out rounded corners."""
    icon = canvas.resize((size, size), Image.LANCZOS).convert("RGBA")

    big = size * SS
    mask = Image.new("L", (big, big), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        [0, 0, big - 1, big - 1], radius=round(big * CORNER), fill=255
    )
    icon.putalpha(mask.resize((size, size), Image.LANCZOS))
    return icon


def main(argv):
    if len(argv) != 2:
        print(__doc__.strip())
        return 1

    source = Image.open(argv[1]).convert("RGB")

    whole = compose(source, (VAN_LEFT, VAN_TOP, VAN_RIGHT, VAN_BOTTOM))
    front = compose(
        source,
        (VAN_LEFT, VAN_TOP, VAN_LEFT + FRONT_WIDTH, VAN_BOTTOM),
        contrast=1.15,
    )

    for size in (128, 48):
        rounded(whole, size).save(OUT_DIR / f"icon{size}.png")
    for size in (32, 16):
        rounded(front, size).save(OUT_DIR / f"icon{size}.png")

    print(f"wrote icon16, icon32, icon48 and icon128 to {OUT_DIR}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
